package com.endava.twitter;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TwitterApplicationTests {

	@Test
	void contextLoads() {
	}

}
